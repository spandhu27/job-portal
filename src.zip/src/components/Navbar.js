import React from 'react';
import { Link, NavLink } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

function Navbar() {
  const { user, logout } = useAuth();

  const handleLogout = () => logout();

  return (
    <nav className="bg-white shadow sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-6 py-4 flex justify-between items-center">
        <Link to="/" className="text-2xl font-bold text-blue-700">JobPortal</Link>
        
        <div className="space-x-4 text-sm md:text-base">
          <NavLink to="/jobs" className={({ isActive }) => isActive ? 'text-blue-600 font-medium' : 'text-gray-600 hover:text-blue-500'}>Jobs</NavLink>
          <NavLink to="/career-advice" className={({ isActive }) => isActive ? 'text-blue-600 font-medium' : 'text-gray-600 hover:text-blue-500'}>Career Advice</NavLink>

          {user ? (
            <>
              <NavLink to="/dashboard" className={({ isActive }) => isActive ? 'text-blue-600 font-medium' : 'text-gray-600 hover:text-blue-500'}>Dashboard</NavLink>
              {user.role === 'employer' && (
                <NavLink to="/post-job" className={({ isActive }) => isActive ? 'text-blue-600 font-medium' : 'text-gray-600 hover:text-blue-500'}>Post a Job</NavLink>
              )}
              <span className="text-gray-700 font-medium ml-2">Hi, {user.username}</span>
              <button
                onClick={handleLogout}
                className="ml-2 bg-red-500 hover:bg-red-600 text-white py-1 px-3 rounded text-sm"
              >
                Logout
              </button>
            </>
          ) : (
            <>
              <NavLink to="/login" className="text-gray-600 hover:text-blue-500">Login</NavLink>
              <NavLink to="/register" className="ml-2 bg-blue-600 text-white py-1.5 px-4 rounded hover:bg-blue-700 transition">
                Register
              </NavLink>
            </>
          )}
        </div>
      </div>
    </nav>
  );
}

export default Navbar;
