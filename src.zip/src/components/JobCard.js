import React from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

function JobCard({ job }) {
  const { user } = useAuth();
  const shortDescription =
    (job.description?.substring(0, 100) ?? 'No description available') + '...';

  return (
    <div className="bg-white p-6 rounded-xl shadow hover:shadow-lg transition border border-gray-200">
      {!job ? (
        <p>Loading...</p>
      ) : (
        <>
          <h3 className="text-xl font-bold text-gray-800 mb-2">{job.title}</h3>
          <p className="text-blue-700 font-medium mb-1">{job.company}</p>
          <p className="text-gray-500 text-sm mb-4">{job.location}</p>
          <p className="text-gray-700 mb-4">{shortDescription}</p>

          <div className="flex justify-between items-center">
            <Link
              to={`/job/${job.id}`}
              className="text-sm text-blue-600 hover:underline"
            >
              View Details
            </Link>
            {user ? (
              <Link
                to={`/job/${job.id}?apply=true`}
                className="bg-green-500 text-white text-sm px-4 py-2 rounded-md hover:bg-green-600 transition"
              >
                Apply Now
              </Link>
            ) : (
              <Link
                to="/login"
                className="bg-gray-400 text-white text-sm px-4 py-2 rounded-md"
              >
                Login to Apply
              </Link>
            )}
          </div>
        </>
      )}
    </div>
  );
}

export default JobCard;
