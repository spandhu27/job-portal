import React from 'react';

const stats = [
  { icon: '💼', count: '200+', label: 'Active Jobs' },
  { icon: '👥', count: '100+', label: 'Job Seekers' },
  { icon: '🏢', count: '25+', label: 'Companies' },
];

const Stats = () => (
  <section className="bg-blue-900 text-white py-16">
    <div className="max-w-5xl mx-auto px-4 flex flex-col md:flex-row justify-around items-center text-center gap-10">
      {stats.map((s) => (
        <div key={s.label} className="flex flex-col items-center">
          <div className="text-5xl mb-2">{s.icon}</div>
          <div className="text-3xl font-bold">{s.count}</div>
          <div className="mt-2 text-sm uppercase tracking-wide text-blue-200">
            {s.label}
          </div>
        </div>
      ))}
    </div>
  </section>
);

export default Stats;
