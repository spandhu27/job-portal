import React, { useState, useEffect } from 'react';
import JobCard from './JobCard'; 
function Job() {
  const [jobs, setJobs] = useState([]);
  const handleApply = async (jobId) => {
    const token = localStorage.getItem('token');
    if (!token) {
      alert('Please log in to apply for a job.');
      return;
    }
    try {
      const response = await fetch(`http://localhost:5000/api/jobs/${jobId}/apply`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        }
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.message);
      alert(data.message);
    } catch (error) {
      alert(`Error: ${error.message}`);
    }
  };
  useEffect(() => {
    fetch('http://localhost:5000/api/jobs')
      .then(res => res.json())
      .then(data => setJobs(data));
  }, []);

  return (
    <div className="max-w-7xl mx-auto py-12 px-4">
      <h2 className="text-3xl font-bold text-center mb-8">Active Jobs</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {jobs.map(job => (
          <JobCard 
            key={job.id} 
            job={job} 
            onApplyClick={handleApply} 
          />
        ))}
      </div>
    </div>
  );
}
export default Job;