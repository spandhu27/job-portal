import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const Hero = () => {
  const [keyword, setKeyword] = useState('');
  const [location, setLocation] = useState('');
  const navigate = useNavigate();

  const handleSearch = (e) => {
    e.preventDefault();
    navigate(`/jobs?q=${keyword}&location=${location}`);
  };

  return (
    <section className="bg-gradient-to-r from-blue-50 to-blue-100 py-20">
      <div className="max-w-4xl mx-auto text-center px-6">
        <h1 className="text-4xl md:text-5xl font-extrabold text-gray-800 leading-tight">
          Find Your <span className="text-blue-600">Dream Job</span> Today
        </h1>
        <p className="text-gray-600 mt-4 text-lg">
          Connect with top employers and discover amazing career opportunities.
        </p>

        {}
        <form
          onSubmit={handleSearch}
          className="mt-10 bg-white p-6 rounded-2xl shadow-lg grid grid-cols-1 md:grid-cols-[2fr_2fr_1fr] gap-4 items-center"
        >
          <input
            type="text"
            placeholder="Job title, keywords, or company"
            className="border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-400"
            value={keyword}
            onChange={(e) => setKeyword(e.target.value)}
          />
          <input
            type="text"
            placeholder="City, state, or remote"
            className="border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-400"
            value={location}
            onChange={(e) => setLocation(e.target.value)}
          />
          <button
            type="submit"
            className="bg-blue-600 hover:bg-blue-700 text-white font-semibold px-6 py-2 rounded-lg transition"
          >
            Search Jobs
          </button>
        </form>

        {}
        <div className="text-sm text-gray-500 mt-6">
          Popular: Frontend Developer · Product Manager · Data Scientist · UX Designer · Marketing
        </div>
      </div>
    </section>
  );
};

export default Hero;
