import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import JobCard from './JobCard';
import toast from 'react-hot-toast';

const JobList = ({ onApplyClick }) => {
  const [jobs, setJobs] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/api/jobs?limit=6')
      .then(res => {
        if (!res.ok) throw new Error('Failed to fetch jobs');
        return res.json();
      })
      .then(data => setJobs(data))
      .catch(err => toast.error(err.message))
      .finally(() => setLoading(false));
  }, []);

  if (loading) {
    return <div className="text-center py-10 text-lg">Loading jobs...</div>;
  }

  if (jobs.length === 0) {
    return <div className="text-center py-10 text-lg">No jobs found.</div>;
  }

  return (
    <section className="max-w-6xl mx-auto py-14 px-6">
      <h2 className="text-3xl font-bold text-center text-gray-800 mb-10">
        🌟 Featured Jobs
      </h2>
      <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
        {jobs.map(job => (
          <JobCard key={job.id} job={job} onApplyClick={onApplyClick} />
        ))}
      </div>
      <div className="text-center mt-10">
        <Link to="/jobs">
          <button className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg font-medium transition">
            View All Jobs →
          </button>
        </Link>
      </div>
    </section>
  );
};

export default JobList;
