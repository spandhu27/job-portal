import React from 'react';
import { Link } from 'react-router-dom';

const CTA = () => {
  return (
    <section className="bg-gradient-to-r from-blue-800 to-blue-600 text-white py-20">
      <div className="max-w-4xl mx-auto text-center px-6">
        <h2 className="text-4xl md:text-5xl font-bold mb-4">
          Ready to Find Your Dream Job?
        </h2>
        <p className="text-lg mb-10">
          Join thousands of professionals who found their perfect career match.
        </p>
        <div className="flex flex-col sm:flex-row justify-center items-center space-y-4 sm:space-y-0 sm:space-x-4">
          <Link to="/register">
            <button className="bg-white text-blue-800 font-bold py-3 px-6 rounded-lg hover:bg-gray-100 transition">
              Sign Up as Job Seeker
            </button>
          </Link>
          <Link to="/register">
            <button className="border-2 border-white font-bold py-3 px-6 rounded-lg hover:bg-white hover:text-blue-800 transition">
              Sign Up as Employer
            </button>
          </Link>
        </div>
      </div>
    </section>
  );
};

export default CTA;
