import React from 'react';

const companies = [
  {
    name: 'InnovateLab',
    industry: 'Software',
    rating: '4.6',
    size: '500–1000 employees',
    location: 'New York, NY',
    open: '8 open positions'
  },
  // Add more companies if needed
];

const Companies = () => (
  <section className="max-w-6xl mx-auto py-14 px-6">
    <h2 className="text-3xl font-bold text-gray-800 mb-10 text-center">
      🔝 Top Hiring Companies
    </h2>
    <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
      {companies.map((c, i) => (
        <div
          key={i}
          className="bg-white rounded-xl shadow-md hover:shadow-xl transition p-6 space-y-4 border-t-4 border-blue-500"
        >
          <div className="h-16 bg-gray-200 rounded mb-2" />
          <h3 className="text-xl font-semibold text-gray-800">{c.name}</h3>
          <p className="text-gray-600">{c.industry}</p>
          <p className="text-yellow-500">★ {c.rating} rating</p>
          <p className="text-gray-500 flex items-center"><span>👥</span><span className="ml-2">{c.size}</span></p>
          <p className="text-gray-500 flex items-center"><span>📍</span><span className="ml-2">{c.location}</span></p>
          <span className="inline-block bg-blue-50 text-blue-700 text-sm font-medium px-3 py-1 rounded">
            {c.open}
          </span>
        </div>
      ))}
    </div>
  </section>
);

export default Companies;
