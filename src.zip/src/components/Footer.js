import React from 'react';
import { Link } from 'react-router-dom';

const Footer = () => {
  return (
    <footer className="bg-gray-50 border-t pt-12 pb-6 text-sm text-gray-600">
      <div className="max-w-7xl mx-auto px-6 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-8">
        <div>
          <h3 className="text-xl font-bold text-blue-800 mb-2">JobPortal</h3>
          <p>Connecting talent with opportunity.</p>
        </div>

        <div>
          <h4 className="font-semibold text-gray-800 mb-2">For Job Seekers</h4>
          <ul className="space-y-1">
            <li><Link to="/jobs" className="hover:text-blue-600">Browse Jobs</Link></li>
            <li><Link to="/feature/career-advice" className="hover:text-blue-600">Career Advice</Link></li>
            <li><Link to="/feature/resume-builder" className="hover:text-blue-600">Resume Builder</Link></li>
          </ul>
        </div>

        <div>
          <h4 className="font-semibold text-gray-800 mb-2">For Employers</h4>
          <ul className="space-y-1">
            <li><Link to="/post-job" className="hover:text-blue-600">Post Jobs</Link></li>
            <li><Link to="/feature/find-candidates" className="hover:text-blue-600">Find Candidates</Link></li>
            <li><Link to="/feature/employer-branding" className="hover:text-blue-600">Employer Branding</Link></li>
          </ul>
        </div>

        <div>
          <h4 className="font-semibold text-gray-800 mb-2">Support</h4>
          <ul className="space-y-1">
            <li><Link to="/feature/help-center" className="hover:text-blue-600">Help Center</Link></li>
            <li><Link to="/feature/contact-us" className="hover:text-blue-600">Contact Us</Link></li>
            <li><Link to="/feature/privacy-policy" className="hover:text-blue-600">Privacy Policy</Link></li>
          </ul>
        </div>
      </div>

      <div className="text-center text-gray-500 mt-10">
        © {new Date().getFullYear()} JobPortal. All rights reserved.
      </div>
    </footer>
  );
};

export default Footer;
