import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext'; 
function ApplicationModel({ jobId }) {
  const [resumeUrl, setResumeUrl] = useState('');
  const [coverLetter, setCoverLetter] = useState('');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const { token, user } = useAuth(); 
  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setSuccess('');
    if (!token) {
      setError('You must be logged in to apply.');
      return;
    }
    try {
      const response = await fetch('/api/apply', { 
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify({ jobId, resumeUrl, coverLetter }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.message || 'Application failed.');
      }
      
      setSuccess('Application submitted successfully!');

    } catch (err) {
      setError(err.message);
    }
  };
  if (!user) {
    return (
        <div>
            <h3 className="text-xl font-bold mb-4">Apply for this Job</h3>
            <p className="text-red-500">Please log in or register to apply.</p>
        </div>
    );
  }
  return (
    <div>
        <h3 className="text-xl font-bold mb-4">Apply for this Job</h3>
        <form onSubmit={handleSubmit}>
            {/* Your form inputs for resumeUrl, coverLetter, etc. */}
            <div className="mb-4">
                <label>Resume URL</label>
                <input type="text" value={resumeUrl} onChange={(e) => setResumeUrl(e.target.value)} className="w-full p-2 border rounded"/>
            </div>
            <div className="mb-4">
                <label>Cover Letter (Optional)</label>
                <textarea value={coverLetter} onChange={(e) => setCoverLetter(e.target.value)} className="w-full p-2 border rounded" rows="4"></textarea>
            </div>

            {error && <p className="text-red-500 mb-4">{error}</p>}
            {success && <p className="text-green-500 mb-4">{success}</p>}

            <button type="submit" className="w-full bg-blue-500 text-white p-2 rounded hover:bg-blue-600">
                Submit Application
            </button>
        </form>
    </div>
  );
}
export default ApplicationModel;