import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import HomePage from './pages/HomePage';
import AllJobsPage from './pages/AllJobsPage';
import JobDetailsPage from './pages/JobDetailsPage';
import PostJobPage from './pages/PostJobPage';
import ComingSoonPage from './pages/ComingSoonPage';
import ArticleListPage from './pages/ArticleListPage';
import ArticleDetailPage from './pages/ArticleDetailPage';
import ResumeBuilder from './pages/ResumeBuilder';
import ForgotPasswordPage from './pages/ForgotPasswordPage';
import ResetPassword from './pages/ResetPassword';
import RegistrationForm from './components/RegistrationForm';
import Login from './components/Login'; 
import ProtectedRoute from './components/ProtectedRoute';
import DashboardPage from './pages/DashboardPage';

function App() {
  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <Navbar />
      <main className="flex-grow">
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/jobs" element={<AllJobsPage />} />
          <Route path="/job/:jobId" element={<JobDetailsPage />} />
          <Route path="/register" element={<RegistrationForm />} />
          <Route path="/login" element={<Login />} />
          <Route 
            path="/dashboard" 
            element={
              <ProtectedRoute>
                <DashboardPage />
              </ProtectedRoute>
            } 
          />
          <Route 
            path="/post-job" 
            element={
              <ProtectedRoute>
                <PostJobPage />
              </ProtectedRoute>
            } 
          />
          <Route path="/career-advice" element={<ArticleListPage />} />
          <Route path="/career-advice/:slug" element={<ArticleDetailPage />} />
          <Route path="/feature/resume-builder" element={<ResumeBuilder />} />
          <Route path="/feature/:featureName" element={<ComingSoonPage />} />
          <Route path="/resume-builder" element={<ResumeBuilder />} />
          <Route path="/forgot-password" element={<ForgotPasswordPage/>} />
          <Route path="/reset-password/:token" element={<ResetPassword />} />
        </Routes>
      </main>
      <Footer />
    </div>
  );
}
export default App;
