import React, { useState } from 'react';
import Hero from '../components/Hero';
import Stats from '../components/Stats';
import JobList from '../components/JobList';
import Companies from '../components/Companies';
import CTA from '../components/CTA';
import ApplicationForm from '../components/ApplicationForm'; 
function HomePage() {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedJobId, setSelectedJobId] = useState(null);
  const handleApplyClick = (jobId) => {
    setSelectedJobId(jobId);
    setIsModalOpen(true);
  };
  const handleCloseModal = () => {
    setIsModalOpen(false);
    setSelectedJobId(null);
  };
  const handleSubmitSuccess = () => {
    alert('Application submitted successfully!');
    handleCloseModal();
  };
  return (
    <div className="bg-gray-50 min-h-screen">
      {}
      <section className="mb-10">
        <Hero />
      </section>
      {}
      <section className="py-6 bg-white shadow-md rounded-lg mx-4 md:mx-16 lg:mx-32 mb-8">
        <Stats />
      </section>
      {}
      <section className="mx-4 md:mx-16 lg:mx-32 mb-12">
        <h2 className="text-2xl md:text-3xl font-semibold text-gray-800 mb-6 border-b-2 border-blue-500 pb-2">
          Latest Job Openings
        </h2>
        <JobList onApplyClick={handleApplyClick} />
      </section>
      {}
      <section className="mx-4 md:mx-16 lg:mx-32 mb-12">
        <h2 className="text-2xl md:text-3xl font-semibold text-gray-800 mb-6 border-b-2 border-green-500 pb-2">
          Top Hiring Companies
        </h2>
        <Companies />
      </section>
      {}
      <section className="bg-gradient-to-r from-blue-500 to-indigo-600 text-white py-12 px-4 md:px-16">
        <CTA />
      </section>
      {}
      {isModalOpen && (
        <ApplicationForm
          jobId={selectedJobId}
          onClose={handleCloseModal}
          onSubmitSuccess={handleSubmitSuccess}
        />
      )}
    </div>
  );
}
export default HomePage;
