import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import ApplicationForm from '../components/ApplicationForm';
import { useAuth } from '../context/AuthContext'; 
const JobDetailsPage = () => {
  const { jobId } = useParams();
  const [job, setJob] = useState(null);
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const { token, user } = useAuth(); 
  useEffect(() => {
    fetch(`/api/jobs/${jobId}`)
      .then(res => res.json())
      .then(data => {
        setJob(data);
        setLoading(false);
      })
      .catch(err => {
        console.error("Failed to fetch job details:", err);
        setLoading(false);
      });
  }, [jobId]);
  const handleSubmitSuccess = () => {
    alert('Application submitted successfully!');
    setIsModalOpen(false);
  };
  if (loading) {
    return <p className="text-center p-8">Loading...</p>;
  }
  if (!job) {
    return <p className="text-center p-8">Job not found.</p>;
  }
  return (
    <>
      <section className="max-w-4xl mx-auto py-12 px-6">
        {}
        <div className="bg-white p-8 rounded-lg shadow-md">
          <Link to="/jobs" className="text-blue-600 hover:underline mb-4 inline-block">← Back to Jobs</Link>
          <h1 className="text-3xl font-bold mb-2">{job.title}</h1>
          <h2 className="text-xl text-gray-700 mb-4">{job.company} - <span className="text-gray-500">{job.location}</span></h2>
          <div className="mb-6">
            <button 
              onClick={() => setIsModalOpen(true)}
              className="bg-blue-600 text-white px-6 py-2 rounded hover:bg-blue-700"
            >
              Apply Now
            </button>
          </div>
          <h3 className="text-lg font-semibold mb-2">Job Description</h3>
          <p className="text-gray-600 whitespace-pre-wrap mb-6">{job.description || 'No description available.'}</p>
          <h3 className="text-lg font-semibold mb-2">Salary</h3>
          <p className="text-gray-600">{job.salary || 'Negotiable'}</p>
        </div>
      </section>

      {isModalOpen && (
        <ApplicationForm
          jobId={job.id}
          onClose={() => setIsModalOpen(false)}
          onSubmitSuccess={handleSubmitSuccess}
          token={token}
          user={user}
        />
      )}
    </>
  );
};
export default JobDetailsPage;