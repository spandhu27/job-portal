import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext'; 

const PostJobPage = () => {
  const [formData, setFormData] = useState({
    title: '',
    companyId: '',
    location: '',
    salary: '',
    description: '',
    jobType: 'full-time'
  });
  const [companies, setCompanies] = useState([]);
  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const navigate = useNavigate();
  const { token, user } = useAuth(); 

  useEffect(() => {
    // Fetch companies for dropdown
    fetch('/api/companies')
      .then(res => res.json())
      .then(data => setCompanies(data))
      .catch(err => console.error('Failed to fetch companies:', err));
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prevState => ({ ...prevState, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    setError('');
    
    try {
      if (!token) {
        setError("Authentication Error: You are not logged in.");
        setSubmitting(false);
        return;
      }

      if (user?.role !== 'employer') {
        setError("Only employers can post jobs.");
        setSubmitting(false);
        return;
      }

      const response = await fetch('/api/jobs', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}` 
        },
        body: JSON.stringify(formData)
      });
      
      const result = await response.json();
      
      if (!response.ok) {
        throw new Error(result.message || 'Failed to post job.');
      }
      
      alert('Job posted successfully!');
      navigate('/jobs');
    } catch (err) {
      setError(err.message);
    } finally {
      setSubmitting(false);
    }
  };

  if (user?.role !== 'employer') {
    return (
      <section className="max-w-2xl mx-auto py-12 px-6">
        <div className="bg-white p-8 rounded-lg shadow-md text-center">
          <h1 className="text-3xl font-bold mb-6">Access Denied</h1>
          <p className="text-red-500">Only employers can post jobs. Please log in with an employer account.</p>
        </div>
      </section>
    );
  }

  return (
    <section className="max-w-2xl mx-auto py-12 px-6">
      <div className="bg-white p-8 rounded-lg shadow-md">
        <h1 className="text-3xl font-bold mb-6 text-center">Post a New Job</h1>
        <form onSubmit={handleSubmit}>
          <div className="space-y-4">
            <div>
              <label htmlFor="title" className="block font-medium">Job Title</label>
              <input 
                type="text" 
                name="title" 
                id="title" 
                value={formData.title} 
                onChange={handleChange} 
                className="w-full border rounded px-3 py-2 mt-1" 
                required 
              />
            </div>
            
            <div>
              <label htmlFor="companyId" className="block font-medium">Company</label>
              <select 
                name="companyId" 
                id="companyId" 
                value={formData.companyId} 
                onChange={handleChange} 
                className="w-full border rounded px-3 py-2 mt-1"
              >
                <option value="">Select a company</option>
                {companies.map(company => (
                  <option key={company.id} value={company.id}>
                    {company.name}
                  </option>
                ))}
              </select>
            </div>
            
            <div>
              <label htmlFor="location" className="block font-medium">Location</label>
              <input 
                type="text" 
                name="location" 
                id="location" 
                value={formData.location} 
                onChange={handleChange} 
                className="w-full border rounded px-3 py-2 mt-1" 
                required 
              />
            </div>
            
            <div>
              <label htmlFor="salary" className="block font-medium">Salary Range (e.g., $90,000 - $110,000)</label>
              <input 
                type="text" 
                name="salary" 
                id="salary" 
                value={formData.salary} 
                onChange={handleChange} 
                className="w-full border rounded px-3 py-2 mt-1" 
              />
            </div>
            
            <div>
              <label htmlFor="jobType" className="block font-medium">Job Type</label>
              <select 
                name="jobType" 
                id="jobType" 
                value={formData.jobType} 
                onChange={handleChange} 
                className="w-full border rounded px-3 py-2 mt-1"
                required
              >
                <option value="full-time">Full-Time</option>
                <option value="part-time">Part-Time</option>
                <option value="contract">Contract</option>
                <option value="internship">Internship</option>
              </select>
            </div>
            
            <div>
              <label htmlFor="description" className="block font-medium">Job Description</label>
              <textarea 
                name="description" 
                id="description" 
                value={formData.description} 
                onChange={handleChange} 
                rows="6" 
                className="w-full border rounded px-3 py-2 mt-1" 
                required
              ></textarea>
            </div>
          </div>
          
          {error && <p className="text-red-500 mt-4 text-center">{error}</p>}
          
          <div className="mt-6">
            <button 
              type="submit" 
              disabled={submitting} 
              className="w-full bg-blue-600 text-white font-bold py-3 px-6 rounded-lg hover:bg-blue-700 transition disabled:bg-blue-400"
            >
              {submitting ? 'Posting...' : 'Post Job'}
            </button>
          </div>
        </form>
      </div>
    </section>
  );
};

export default PostJobPage;