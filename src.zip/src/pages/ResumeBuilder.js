import React, { useState } from 'react';
const ResumeBuilderPage = () => {
  const [name, setName] = useState('');
  const [summary, setSummary] = useState('');
  const [skills, setSkills] = useState('');
  const handleSubmit = (e) => {
    e.preventDefault();
    alert(`Resume created for ${name}`);
  };
  return (
    <div className="max-w-2xl mx-auto py-10">
      <h1 className="text-3xl font-bold mb-6">Resume Builder</h1>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block font-semibold">Full Name</label>
          <input
            type="text"
            className="w-full p-2 border rounded"
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
          />
        </div>
        <div>
          <label className="block font-semibold">Summary</label>
          <textarea
            className="w-full p-2 border rounded"
            value={summary}
            onChange={(e) => setSummary(e.target.value)}
            rows={3}
          />
        </div>
        <div>
          <label className="block font-semibold">Skills</label>
          <input
            type="text"
            className="w-full p-2 border rounded"
            value={skills}
            onChange={(e) => setSkills(e.target.value)}
            placeholder="e.g. React, Java, SQL"
          />
        </div>
        <button type="submit" className="bg-blue-600 text-white px-4 py-2 rounded">
          Generate Resume
        </button>
      </form>
    </div>
  );
};
export default ResumeBuilderPage;
