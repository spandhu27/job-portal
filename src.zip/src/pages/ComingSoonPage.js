import React from 'react';
import { useParams, Link } from 'react-router-dom';
const formatFeatureName = (name) => {
  if (!name) return 'Feature';
  return name
    .split('-') 
    .map(word => word.charAt(0).toUpperCase() + word.slice(1)) 
    .join(' '); 
};

const ComingSoonPage = () => {
  const { featureName } = useParams();
  const formattedName = formatFeatureName(featureName);

  return (
    <div className="flex flex-col items-center justify-center text-center py-20 px-6">
      <div className="bg-white p-10 rounded-lg shadow-lg">
        <h1 className="text-4xl font-bold text-gray-800 mb-4">
          {formattedName}
        </h1>
        <p className="text-lg text-gray-600 mb-6">
          This feature is currently under development. Please check back soon!
        </p>
        <Link to="/">
          <button className="bg-blue-600 text-white font-bold py-3 px-6 rounded-lg hover:bg-blue-700 transition">
            ← Go Back Home
          </button>
        </Link>
      </div>
    </div>
  );
};

export default ComingSoonPage;

