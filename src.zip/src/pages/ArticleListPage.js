import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';

const ArticleListPage = () => {
  const [articles, setArticles] = useState([]);
  const [loading, setLoading] = useState(true);

  // 👉 Replace fetch logic with mock data
  useEffect(() => {
    const mockArticles = [
      {
        id: 1,
        title: 'How to Crack a Tech Interview',
        slug: 'crack-tech-interview',
        author: 'Jane Doe',
        published_at: '2025-06-20',
        excerpt: 'Learn the secrets to passing technical interviews...',
      },
      {
        id: 2,
        title: 'Top 10 Skills for a Developer',
        slug: 'top-10-dev-skills',
        author: 'John Smith',
        published_at: '2025-06-18',
        excerpt: 'These skills will help you land your dream dev job...',
      }
    ];
    setArticles(mockArticles);
    setLoading(false);
  }, []);

  if (loading) return <p className="text-center p-8">Loading articles...</p>;

  return (
    <section className="max-w-4xl mx-auto py-12 px-6">
      <h1 className="text-4xl font-bold text-center mb-10">Career Advice</h1>
      <div className="space-y-8">
        {articles.map(article => (
          <div key={article.id} className="bg-white p-6 rounded-lg shadow-md">
            <h2 className="text-2xl font-semibold mb-2">
              <Link to={`/career-advice/${article.slug}`} className="text-blue-700 hover:underline">
                {article.title}
              </Link>
            </h2>
            <p className="text-sm text-gray-500 mb-4">
              By {article.author} on {new Date(article.published_at).toLocaleDateString()}
            </p>
            <p className="text-gray-700 mb-4">{article.excerpt}</p>
            <Link
              to={`/career-advice/${article.slug}`}
              className="inline-block text-blue-600 hover:text-blue-800 font-semibold"
              aria-label={`Read more about ${article.title}`}
            >
              Read More →
            </Link>
          </div>
        ))}
      </div>
    </section>
  );
};

export default ArticleListPage;
