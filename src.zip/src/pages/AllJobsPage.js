import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import JobCard from '../components/JobCard';
import ApplicationForm from '../components/ApplicationForm';
function useQuery() {
  return new URLSearchParams(useLocation().search);
}
const AllJobsPage = () => {
  const [jobs, setJobs] = useState([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedJobId, setSelectedJobId] = useState(null);
  const query = useQuery();
  useEffect(() => {
    const keyword = query.get('q') || '';
    const location = query.get('location') || '';
    fetch(`/api/jobs?q=${keyword}&location=${location}`)
      .then(res => res.json())
      .then(data => setJobs(data))
      .catch(err => console.error("Failed to fetch jobs:", err));
  }, [query.toString()]); 
  const handleApplyClick = (jobId) => {
    setSelectedJobId(jobId);
    setIsModalOpen(true);
  };
  const handleCloseModal = () => {
    setIsModalOpen(false);
    setSelectedJobId(null);
  };
  const handleSubmitSuccess = () => {
    alert('Application submitted successfully!');
    handleCloseModal();
  };
  return (
    <>
      <section className="max-w-5xl mx-auto py-12 px-6">
        <h1 className="text-3xl font-bold text-center mb-8">
          {query.get('q') ? 'Search Results' : 'All Available Jobs'}
        </h1>
        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
          {jobs.length > 0 ? (
            jobs.map(job => (
              <JobCard
                key={job.id}
                job={job}
                onApplyClick={handleApplyClick}
              />
            ))
          ) : (
            <p className="col-span-3 text-center text-gray-500">No jobs found matching your criteria.</p>
          )}
        </div>
      </section>
      {isModalOpen && (
        <ApplicationForm
          jobId={selectedJobId}
          onClose={handleCloseModal}
          onSubmitSuccess={handleSubmitSuccess}
        />
      )}
    </>
  );
};
export default AllJobsPage;