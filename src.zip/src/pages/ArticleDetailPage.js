import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';

const ArticleDetailPage = () => {
  const { slug } = useParams();
  const [article, setArticle] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Mocked data
    const mockArticles = [
      {
        id: 1,
        slug: 'crack-tech-interview',
        title: 'How to Crack a Tech Interview',
        author: 'Jane Doe',
        published_at: '2025-06-20',
        content: `<p>Preparing for tech interviews can be challenging. This guide will walk you through...</p>`
      },
      {
        id: 2,
        slug: 'top-10-dev-skills',
        title: 'Top 10 Skills for a Developer',
        author: 'John Smith',
        published_at: '2025-06-18',
        content: `<ul><li>Problem Solving</li><li>Version Control</li><li>Communication</li></ul>`
      }
    ];

    const foundArticle = mockArticles.find(article => article.slug === slug);
    setArticle(foundArticle);
    setLoading(false);
  }, [slug]);

  if (loading) return <p className="text-center p-8">Loading article...</p>;
  if (!article) return <p className="text-center p-8 text-red-500">Article not found.</p>;

  return (
    <article className="max-w-3xl mx-auto py-12 px-6">
      <h1 className="text-4xl font-bold mb-4">{article.title}</h1>
      <p className="text-sm text-gray-500 mb-6">
        By {article.author} on {new Date(article.published_at).toLocaleDateString()}
      </p>
      <div
        className="prose prose-lg max-w-none"
        dangerouslySetInnerHTML={{ __html: article.content }}
      />
    </article>
  );
};

export default ArticleDetailPage;
